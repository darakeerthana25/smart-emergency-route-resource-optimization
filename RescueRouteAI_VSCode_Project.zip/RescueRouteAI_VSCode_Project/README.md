# RescueRoute AI — VS Code-ready project

Project: Smart Emergency Route and Resource Optimization Using Advanced Algorithms

This starter project contains a React/Vite frontend and an Express backend. It demonstrates Dijkstra, A*, BFS, Floyd–Warshall, road closures, and a simple greedy resource-allocation endpoint using simulated road data.

## Run locally
Requirements: Node.js 18+ and npm.
1. Extract the ZIP and open the folder in VS Code.
2. Open a terminal in the project folder.
3. Run `npm install` and `npm run install:all`.
4. Run `npm run dev`.
5. Open http://localhost:5173. Backend health: http://localhost:4000/api/health.

## Important
This is a standalone source project/starter. If your existing Replit site uses different source code, do not claim this exact code created that site unless you actually adopt and run it. Be ready to explain the code. Road data and travel weights are simulated; this is not a real dispatch system.

## Architecture
React frontend -> Express API -> graph algorithms / resource allocator -> JSON results -> frontend.

## Complexity notes
BFS: O(V+E), minimizes edge count on an unweighted graph.
Floyd–Warshall: O(V^3) time, O(V^2) distance matrix space.
Dijkstra/A* bounds depend on the actual priority-queue implementation and heuristic. This educational Dijkstra implementation uses a simple array scan, not a binary heap; do not claim the binary-heap bound for this exact implementation.
