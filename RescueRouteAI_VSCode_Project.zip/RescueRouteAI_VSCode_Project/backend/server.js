import express from 'express';
import cors from 'cors';
import { graph, adj, dijkstra, astar, bfs, floyd } from './src/algorithms.js';
import { allocate } from './src/resources.js';
const app=express(); app.use(cors()); app.use(express.json());
app.get('/api/health',(_,res)=>res.json({ok:true,service:'RescueRoute API'}));
app.get('/api/graph',(_,res)=>res.json(graph));
app.post('/api/route',(req,res)=>{
 const {algorithm='dijkstra',source='A',destination='J',network=graph}=req.body||{};
 try { const t=performance.now(); let result;
 if(algorithm==='dijkstra') result=dijkstra(network,source,destination);
 else if(algorithm==='astar') result=astar(network,source,destination);
 else if(algorithm==='bfs') result=bfs(network,source,destination);
 else if(algorithm==='floyd-warshall') result=floyd(network,source,destination);
 else return res.status(400).json({error:'Unknown algorithm'});
 result.algorithm=algorithm; result.runtimeMs=Number((performance.now()-t).toFixed(4)); res.json(result);
 } catch(e){res.status(400).json({error:e.message});}
});
app.post('/api/road',(req,res)=>{
 const {network=graph,from,to,blocked,weight}=req.body||{}; const copy=JSON.parse(JSON.stringify(network));
 const edge=copy.edges.find(e=>(e.from===from&&e.to===to)||(e.from===to&&e.to===from));
 if(!edge)return res.status(404).json({error:'Road not found'});
 if(typeof blocked==='boolean')edge.blocked=blocked;
 if(Number.isFinite(weight)){if(weight<0)return res.status(400).json({error:'Weight must be non-negative'});edge.weight=weight;}
 res.json(copy);
});
app.post('/api/resources/allocate',(req,res)=>res.json(allocate(req.body||{})));
app.listen(4000,()=>console.log('API listening on http://localhost:4000'));
