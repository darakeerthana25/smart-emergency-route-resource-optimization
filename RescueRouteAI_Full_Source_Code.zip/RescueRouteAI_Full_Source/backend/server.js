import express from "express";
import cors from "cors";
import { SAMPLE_NETWORK, validateNetwork, calculateRoute, calculateAllPairs } from "./src/algorithms.js";
import { allocateResources } from "./src/resources.js";
const app = express(), PORT = Number(process.env.PORT || 4000);
app.use(cors()); app.use(express.json({limit:"1mb"}));
app.get("/api/health", (_req,res)=>res.json({status:"ok",service:"RescueRoute AI API"}));
app.get("/api/network", (_req,res)=>res.json(SAMPLE_NETWORK));
app.post("/api/route",(req,res)=>{
 const {network=SAMPLE_NETWORK,algorithm="dijkstra",source,destination,blockedRoads=[]}=req.body??{};
 const check=validateNetwork(network); if(!check.valid)return res.status(400).json({error:check.error});
 if(!source||!destination)return res.status(400).json({error:"source and destination are required."});
 const t=performance.now();
 try { const result=calculateRoute(network,{algorithm,source,destination,blockedRoads}); result.runtimeMs=Number((performance.now()-t).toFixed(3)); res.json(result); }
 catch(e){res.status(400).json({error:e.message});}
});
app.post("/api/all-pairs",(req,res)=>{
 const {network=SAMPLE_NETWORK,blockedRoads=[]}=req.body??{}; const check=validateNetwork(network);
 if(!check.valid)return res.status(400).json({error:check.error});
 try{res.json(calculateAllPairs(network,blockedRoads));}catch(e){res.status(400).json({error:e.message});}
});
app.post("/api/resources/allocate",(req,res)=>{
 const {incidents=[],resources=[]}=req.body??{};
 if(!Array.isArray(incidents)||!Array.isArray(resources))return res.status(400).json({error:"incidents and resources must be arrays."});
 res.json(allocateResources(incidents,resources));
});
app.listen(PORT,()=>console.log(`RescueRoute AI API running on http://localhost:${PORT}`));
