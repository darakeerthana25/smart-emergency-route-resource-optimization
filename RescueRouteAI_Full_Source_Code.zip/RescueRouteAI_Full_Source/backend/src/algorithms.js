export const SAMPLE_NETWORK={nodes:[
{id:"A",name:"Central Hospital",x:70,y:180,heuristic:0},{id:"B",name:"North Junction",x:180,y:70,heuristic:4},
{id:"C",name:"City Market",x:205,y:220,heuristic:3},{id:"D",name:"Fire Station",x:335,y:70,heuristic:5},
{id:"E",name:"River Bridge",x:355,y:205,heuristic:2},{id:"F",name:"East Clinic",x:485,y:135,heuristic:1},
{id:"G",name:"Rescue Center",x:555,y:245,heuristic:0}],
edges:[{from:"A",to:"B",weight:4},{from:"A",to:"C",weight:2},{from:"B",to:"C",weight:1},{from:"B",to:"D",weight:5},{from:"C",to:"D",weight:8},{from:"C",to:"E",weight:10},{from:"D",to:"E",weight:2},{from:"D",to:"F",weight:6},{from:"E",to:"F",weight:2},{from:"E",to:"G",weight:6},{from:"F",to:"G",weight:3}]};
export function validateNetwork(n){
 if(!n||!Array.isArray(n.nodes)||!Array.isArray(n.edges))return{valid:false,error:"network must contain nodes and edges arrays."};
 const ids=new Set(n.nodes.map(x=>x.id)); if(ids.size!==n.nodes.length)return{valid:false,error:"Node IDs must be unique."};
 for(const e of n.edges)if(!ids.has(e.from)||!ids.has(e.to)||!Number.isFinite(+e.weight)||+e.weight<0)return{valid:false,error:"Edges must use existing nodes and non-negative weights."};
 return{valid:true};
}
const key=(a,b)=>[a,b].sort().join("::");
function adjacency(n,blocked=[]){
 const closed=new Set(blocked.map(e=>Array.isArray(e)?key(...e):String(e))), map=new Map(n.nodes.map(x=>[x.id,[]]));
 for(const e of n.edges){if(closed.has(key(e.from,e.to))||closed.has(`${e.from}-${e.to}`)||closed.has(`${e.to}-${e.from}`))continue;
 map.get(e.from).push({id:e.to,weight:+e.weight});map.get(e.to).push({id:e.from,weight:+e.weight});}return map;
}
function pathFrom(prev,s,d){if(s===d)return[s];if(!prev.has(d))return[];const p=[];let u=d;while(u!==undefined){p.unshift(u);if(u===s)break;u=prev.get(u);}return p[0]===s?p:[];}
function dijkstra(n,s,d,blocked){const adj=adjacency(n,blocked),dist=new Map(n.nodes.map(x=>[x.id,Infinity])),prev=new Map(),done=new Set();dist.set(s,0);
 while(done.size<n.nodes.length){let u=null,best=Infinity;for(const [id,v]of dist)if(!done.has(id)&&v<best){u=id;best=v;}if(u===null||u===d)break;done.add(u);
 for(const v of adj.get(u)){const nd=dist.get(u)+v.weight;if(nd<dist.get(v.id)){dist.set(v.id,nd);prev.set(v.id,u);}}}
 const path=pathFrom(prev,s,d);return{path,distance:path.length?dist.get(d):null,visitedCount:done.size};}
function astar(n,s,d,blocked){const adj=adjacency(n,blocked),byId=new Map(n.nodes.map(x=>[x.id,x])),h=id=>+(byId.get(id)?.heuristic??0),g=new Map(n.nodes.map(x=>[x.id,Infinity])),f=new Map(n.nodes.map(x=>[x.id,Infinity])),prev=new Map(),open=new Set([s]),closed=new Set();g.set(s,0);f.set(s,h(s));
 while(open.size){let u=null,best=Infinity;for(const id of open)if(f.get(id)<best){u=id;best=f.get(id);}if(u===d)break;open.delete(u);closed.add(u);
 for(const v of adj.get(u)){if(closed.has(v.id))continue;const t=g.get(u)+v.weight;if(t<g.get(v.id)){prev.set(v.id,u);g.set(v.id,t);f.set(v.id,t+h(v.id));open.add(v.id);}}}
 const path=pathFrom(prev,s,d);return{path,distance:path.length?g.get(d):null,visitedCount:closed.size};}
function bfs(n,s,d,blocked){const adj=adjacency(n,blocked),q=[s],prev=new Map(),seen=new Set([s]);while(q.length){const u=q.shift();if(u===d)break;for(const v of adj.get(u))if(!seen.has(v.id)){seen.add(v.id);prev.set(v.id,u);q.push(v.id);}}
 const path=pathFrom(prev,s,d);let distance=null;if(path.length){distance=0;for(let i=1;i<path.length;i++){const e=n.edges.find(x=>(x.from===path[i-1]&&x.to===path[i])||(x.to===path[i-1]&&x.from===path[i]));distance+=+(e?.weight??0);}}return{path,distance,visitedCount:seen.size};}
export function calculateAllPairs(n,blocked=[]){const ids=n.nodes.map(x=>x.id),dist={},next={},closed=new Set(blocked.map(e=>Array.isArray(e)?key(...e):String(e)));
 for(const i of ids){dist[i]={};next[i]={};for(const j of ids){dist[i][j]=i===j?0:Infinity;next[i][j]=null;}}
 for(const e of n.edges){if(closed.has(key(e.from,e.to))||closed.has(`${e.from}-${e.to}`)||closed.has(`${e.to}-${e.from}`))continue;dist[e.from][e.to]=dist[e.to][e.from]=+e.weight;next[e.from][e.to]=e.to;next[e.to][e.from]=e.from;}
 for(const k of ids)for(const i of ids)for(const j of ids)if(dist[i][k]+dist[k][j]<dist[i][j]){dist[i][j]=dist[i][k]+dist[k][j];next[i][j]=next[i][k];}return{distances:dist,next};}
export function calculateRoute(n,{algorithm="dijkstra",source,destination,blockedRoads=[]}){const ids=new Set(n.nodes.map(x=>x.id));if(!ids.has(source)||!ids.has(destination))throw Error("Choose valid source and destination nodes.");
 if(source===destination)return{algorithm,path:[source],distance:0,visitedCount:0,message:"Source and destination are the same."};
 let r;if(algorithm==="dijkstra")r=dijkstra(n,source,destination,blockedRoads);else if(algorithm==="astar")r=astar(n,source,destination,blockedRoads);else if(algorithm==="bfs")r=bfs(n,source,destination,blockedRoads);else if(algorithm==="floyd-warshall"){const all=calculateAllPairs(n,blockedRoads),path=[];let u=source;if(all.next[source][destination]!==null){path.push(u);let guard=0;while(u!==destination&&guard++<n.nodes.length+1){u=all.next[u][destination];if(u===null)break;path.push(u);}}r={path:path.at(-1)===destination?path:[],distance:Number.isFinite(all.distances[source][destination])?all.distances[source][destination]:null,visitedCount:n.nodes.length};}else throw Error("Unknown algorithm.");
 return{algorithm,...r,message:r.path.length?"Route found.":"No route available. Try reopening a road."};}
