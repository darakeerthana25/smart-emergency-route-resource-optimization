export function allocateResources(incidents,resources){
 const stock=resources.map((r,i)=>({...r,_i:i,left:Math.max(0,Number(r.count??1))}));
 const ordered=incidents.map((x,i)=>({...x,_i:i,p:Number(x.priority??1)})).sort((a,b)=>b.p-a.p),assignments=[],unassigned=[];
 for(const inc of ordered){const type=String(inc.requiredType??"").toLowerCase();const r=stock.find(x=>x.left>0&&(!type||String(x.type??x.name??"").toLowerCase().includes(type)));
 if(!r){unassigned.push({incidentId:inc.id??`incident-${inc._i+1}`,reason:"No matching resource available."});continue;}
 r.left--;assignments.push({incidentId:inc.id??`incident-${inc._i+1}`,incidentName:inc.name??`Incident ${inc._i+1}`,priority:inc.p,resourceId:r.id??`resource-${r._i+1}`,resourceName:r.name??r.type??"Resource"});}
 return{strategy:"Greedy priority-first assignment",assignments,unassigned,remaining:stock.map(r=>({id:r.id??`resource-${r._i+1}`,name:r.name??r.type??"Resource",remaining:r.left})),note:"Demonstration heuristic; not guaranteed globally optimal."};
}
