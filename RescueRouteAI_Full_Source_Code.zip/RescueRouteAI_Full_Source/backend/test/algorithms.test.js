import test from "node:test";
import assert from "node:assert/strict";
import {SAMPLE_NETWORK,calculateRoute,validateNetwork} from "../src/algorithms.js";
test("sample network validates",()=>assert.equal(validateNetwork(SAMPLE_NETWORK).valid,true));
test("Dijkstra finds route A to G",()=>{const r=calculateRoute(SAMPLE_NETWORK,{algorithm:"dijkstra",source:"A",destination:"G"});assert.equal(r.path[0],"A");assert.equal(r.path.at(-1),"G");assert.ok(r.distance>0);});
test("BFS finds route",()=>{const r=calculateRoute(SAMPLE_NETWORK,{algorithm:"bfs",source:"A",destination:"G"});assert.equal(r.path.at(-1),"G");});
