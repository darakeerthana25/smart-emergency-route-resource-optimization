# RescueRoute AI — Full Source

This is a complete standalone React + Express implementation for the academic project **Smart Emergency Route and Resource Optimization Using Advanced Algorithms**.

## Run in VS Code
Requirements: Node.js 18+ and npm.
1. Extract the ZIP and open `RescueRouteAI_Full_Source` in VS Code.
2. In the root terminal run:
   ```
   npm install
   npm run install:all
   npm run dev
   ```
3. Frontend: http://localhost:5173
4. Backend health: http://localhost:4000/api/health

## Included
- `frontend/`: React/Vite UI, styles, interactive graph, route controls, comparison table, resource-allocation view.
- `backend/`: Express API, graph algorithms, resource allocation, tests.
- Algorithms: Dijkstra, A*, BFS, Floyd–Warshall.
- Road closure simulation and recalculation.

## Important
This is a complete standalone implementation for the project concept, not an exported copy of your existing deployed Replit website. It may differ from that site. To reproduce the exact website, its original source files are needed.

Algorithm notes: Dijkstra here uses array-based minimum selection (O(V² + E)); BFS minimizes edge count rather than weighted cost; Floyd–Warshall is O(V³) time and O(V²) space. Resource allocation is a greedy heuristic, not guaranteed globally optimal. Do not use this academic demo for real emergency dispatch.
